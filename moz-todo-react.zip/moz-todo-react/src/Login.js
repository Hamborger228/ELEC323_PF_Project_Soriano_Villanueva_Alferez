import { useState, useEffect } from 'react';
import { Link, useHistory} from 'react-router-dom';
import Home from './Home';


const Login = () => {
    let username = 'admin'
    let password = '1'
    const [verifyUsername, setVerifyUsername] = useState('');
    const [verifyPassword, setVerifyPassword] = useState('');
    const [isVerify, setIsVerify] = useState(false);
    const history = useHistory();

    const [verifyUser, setVerifyUser] = useState("")
    const [verifyPass, setVerifyPass] = useState("")

    const veryfyLogin = () =>{
        // (verifyUsername !== username || verifyPassword !== (password)) && alert('Incorrect username or password');
        // (verifyUsername === username && verifyPassword === (password)) && setIsVerify(true);
        fetch('http://localhost:8000/Users')
          .then(res => res.json())
          .then(json => {
            try {
                console.log(json)
                const getUser = json.find(Users => Users.Username === verifyUsername )
                setVerifyUser(getUser.Username)
                setVerifyPass(getUser.Password)
            } catch (error) {
                alert('Incorrect username or password')
            }
            (verifyUsername !== (verifyUser) || verifyPassword !== (verifyPass)) && alert('Incorrect username or password');
            (verifyUsername === (verifyUser) && verifyPassword === (verifyPass)) && setIsVerify(true);
            
          })
    }

    return (  
        <div className="LoginPage">
            <input type="text" className="txtUsername" required placeholder="username" onChange={event => setVerifyUsername(event.target.value)}/>
            <input type="password" className="txtPassword" required placeholder="password" onChange={event => setVerifyPassword(event.target.value)}/>
            <Link to={isVerify && history.push('/Home')}><button onClick={veryfyLogin} className="btnSignin" >Sign in</button></Link>
            <Link to='*'><p className="forgotPassword">Forgot Password?</p></Link>
            <Link to='/Register'><p className="register">Register</p></Link>
        </div>
    );
}
 
export default Login;