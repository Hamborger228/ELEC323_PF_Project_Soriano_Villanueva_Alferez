import { useParams } from "react-router-dom";
import useFetch from "./useFetch";
import { Link } from 'react-router-dom';

const ViewJob = () => {

    const { id } = useParams();
    const {data} = useFetch('http://localhost:8000/Job/' + id);

    return ( 
      <div>
      <h3>Job Details</h3>
      <p>Job name</p>
      <input type="text" className="txtUsername" value={data && data.JobName} readOnly/>
      <p>Job description</p>
      <textarea name="" id="" cols="53" rows="3" value={data && data.JobDescription} readOnly type="number" ></textarea>
      <p>Job Rate</p>
      <input type="text" className="txtUsername" value={data && data.JobRate}   readOnly />
      <p>Job Status</p>
      <input type="text" className="txtUsername" value={data && data.JobStatus}   readOnly/>
      <Link to={"/Home"}><button>Back</button></Link>
      </div>
     );
}
 
export default ViewJob;