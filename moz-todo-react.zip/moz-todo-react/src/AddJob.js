import { useState } from 'react';
import { useHistory} from "react-router-dom";

const AddJob = () => {

    const [JobName, setAddJobName] = useState('');
    const [JobDescription, setAddJobDescription] = useState('');
    const [JobRate, setAddJobRate] = useState('');
    let JobStatus = "Pending";
    const history = useHistory('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const addNewJob = { JobName, JobDescription, JobStatus, JobRate };
    
        fetch('http://localhost:8000/Job/', {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(addNewJob)
        }).then(() => {
            history.push('/Home');
        })
      }

    return ( 
      <form className="AddPage" onSubmit={handleSubmit}>
      <h3>Add Job</h3>
      <p>Job name</p>
      <input type="text" className="txtUsername" placeholder="Job name" required onChange={event => setAddJobName(event.target.value)}/>
      <p>Job description</p>
      <textarea name="" id="" cols="53" rows="3" placeholder="Job description" required type="number" onChange={event => setAddJobDescription(event.target.value)}></textarea>
      <p>Job Rate</p>
      <input type="number" className="txtUsername" placeholder="Job rate" required  onChange={event => setAddJobRate((event.target.value)+"$ per Hour")}/>
      <button type="submit" >Add</button>
      </form>
     );
}
 
export default AddJob;