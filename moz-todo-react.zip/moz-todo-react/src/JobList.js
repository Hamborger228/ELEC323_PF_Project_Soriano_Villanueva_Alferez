import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const JobList = ({FilterJob, data}, {User}) => {

    const countOngoing = FilterJob.filter(item => item.JobStatus === 'Ongoing').length;
    const countPending = FilterJob.filter(item => item.JobStatus === 'Pending').length;
    const [filteredList, setFilteredList] = useState(FilterJob);
    const [selectedStatus, setSelectedStatus] = useState("");

    // filter==================================================================
    const filterByStatus = (filteredData) => {
        // Avoid filter for empty string
    if (!selectedStatus) {
        return filteredData;
    }
    const filteredStatus= filteredData.filter(
        (status) => status.JobStatus.split(" ").indexOf(selectedStatus) !== -1
    );
        return filteredStatus;
    };

    const handleStatusChange = (event) => {
        setSelectedStatus(event.target.value);
    };

    useEffect(() => {
        var filteredData = filterByStatus(FilterJob);
        setFilteredList(filteredData);
    },[selectedStatus]);
    // filter================================================================== 

    // const handleClickDelete = () => {
    //     fetch('http://localhost:8000/Todos/' + idCount, {
    //         method: 'DELETE'
    //     }).then(() => {
            
    //     }) 
    // }


    return ( 
        <div className="Job-list">
            <div className="filter"> 
                <select id="status-input" value={selectedStatus} onChange={handleStatusChange}>
                    <option value="">All</option>
                    <option value="Ongoing">Ongoing</option>
                    <option value="Pending">Pending</option>
                </select>
            </div>
            <div className="addJob">
                <Link to={'/AddJob'}><button>Add Job</button></Link>
            </div>

            {filteredList.map((item) => (
                <div className="Job-preview" style={item.JobStatus === "Ongoing" ? {borderBottom: '1px solid gray' , boxShadow: '1px 3px 5px gray' } : {} && item.JobStatus === "Pending" ? {borderBottom: '1px solid #23CE6B' , boxShadow: '1px 3px 5px #23CE6B' } : {}} key={item.id}>
                    <Link to={`/ViewJob/${item.id}`} style={{ textDecoration: 'none' }}>
                    <p className="JobName" style={item.JobStatus === "Ongoing" ? {color: 'gray'} : {}}>{item.JobName}</p>
                    <p className="JobName" style={item.JobStatus === "Ongoing" ? {color: 'gray'} : {}}>{item.JobRate}</p>
                    <p className="JobStatus" ><Link to={`/DeleteConfirm/${item.id}`}><button className="todoRemove">Remove</button></Link></p>  
                    </Link>
                </div>
            ))}
            
            
            <div className="Ongoing">
                <h3>Ongoing</h3>
                <h1>{countOngoing}</h1>
            </div>
            <div className="Pending">
                <h3>Pending</h3>
                <h1>{countPending}</h1>
            </div>
            
        </div>
     );
}
 
export default JobList;

// <p className="todoName"  style={item.TodoPriority === "False" ? {color: '#23CE6B'} : {} || item.TodoPriority === "True" ?{color: '#f1356d'} : {} || item.JobStatus === "Done" ? {color: 'gray'} : {}}>{item.TodoName}</p>