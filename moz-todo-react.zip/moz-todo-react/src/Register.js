import { useState, useEffect } from 'react';
import { useHistory} from "react-router-dom";

const Register = () => {

    const [verifyUser, setVerifyUser] = useState('');
    const [Username, setUsername] = useState('');
    const [Password, setPassword] = useState('');
    const [ConfirmPassword, setConfirmPassword] = useState('');
    const history = useHistory('');

    const handleSubmit = () => {
        if (Username.trim().length === 0 || Password.trim().length === 0 || ConfirmPassword.trim().length === 0){
            alert('Please fill all fields')
        } 
        else if(Password !== ConfirmPassword){
            alert('Password mismatch')
        }
        else {
            fetch('http://localhost:8000/Users')
          .then(res => res.json())
          .then(json => {
            try {
                const getUser = json.find(Users => Users.Username === Username )
                setVerifyUser(getUser.Username)
                alert('User already exist')
            } catch (error) {
                const addNewJob = { Username, Password};
                fetch('http://localhost:8000/Users/', {
                method: 'POST',
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(addNewJob)
                }).then(() => {
                    history.push('/');
                })
            }
          })
        }
      }

    return ( 
      <div>
      <h3>Register User</h3>
      <p>Username</p>
      <input type="text" className="txtUsername" id='txtUsername' placeholder="username" required onChange={event => setUsername(event.target.value)}/>
      <p>Password</p>
      <input type="text" className="txtPassword" placeholder="password" required onChange={event => setPassword(event.target.value)}/>
      <p>Confirm Password</p>
      <input type="text" className="txtConfirmPassword" placeholder="confirm password" required onChange={event => setConfirmPassword(event.target.value)}/>
      <button type="submit" onClick={handleSubmit} >Register</button>
      </div>
     );
}
 
export default Register;